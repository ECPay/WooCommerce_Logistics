<?php
/**
 * 前台 - 移除電子地圖表單
 */

defined('ECPAY_PLUGIN_PATH') || exit;

?>

<script>
    jQuery(document).ready(function($) {
        $("#ECPayForm").remove();
    });
</script>