<?php
/**
 * 前台 - 電子地圖
 */

defined('ECPAY_PLUGIN_PATH') || exit;

?>

<!-- template -->
<div id="ECPayCvsForm">
	<?php echo $html; ?>
</div>

<script>
	document.getElementById('ECPayForm').submit();
</script>